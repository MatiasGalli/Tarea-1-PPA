package logica;

import dominio.DoublyLinkedListItem;

public class DoublyLinkedList {
	public DoublyLinkedListItem first, last;
	
	public DoublyLinkedList() {
		first = null;
		last = null;
	}
	
	public void AddFirst(DoublyLinkedListItem item) {
		
	}
	
	public void AddLast(DoublyLinkedListItem item) {
		
	}
	
	public void AddAfter(DoublyLinkedListItem afterItem,DoublyLinkedListItem newItem) {
		
	}
	
	public void AddBefore(DoublyLinkedListItem beforeItem,DoublyLinkedListItem newItem) {
		
	}
	
	public void Clear() {
		
	}
	
	public void Contains(DoublyLinkedListItem item) {
		
	}
	
	public void Remove(DoublyLinkedListItem item) {
		
	}
	
	public void RemoveFirst() {
		
	}
	
	public void RemoveLast() {
		
	}
}
