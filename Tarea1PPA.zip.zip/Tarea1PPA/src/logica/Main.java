package logica;

public class Main {

}
